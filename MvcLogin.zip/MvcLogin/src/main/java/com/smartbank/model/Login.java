package com.smartbank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "Login")

public class Login  {


	@Id
	@GeneratedValue(generator="Assign")
	@Column(name = "id")
	private Long id;
	
	@Column(name = "userName")
	String userName;

	@Column(name = "userPassword")
	String Password;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}


	
	
}