package com.smartbank.dao;

import com.smartbank.model.*;

public interface LoginDAO{    
       public boolean checkLogin(String userName, String userPassword);
}